﻿namespace ecommercetp1
{
    partial class ResumenForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            groupBox1 = new GroupBox();
            label2 = new Label();
            lblComercios = new Label();
            label3 = new Label();
            lblTiendas = new Label();
            label4 = new Label();
            lblTotalventas = new Label();
            groupBox2 = new GroupBox();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            lblAprobados = new Label();
            lblPendientes = new Label();
            lblRechazados = new Label();
            grpIngresos = new GroupBox();
            label8 = new Label();
            lblIngresos = new Label();
            btnActualizar = new Button();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            grpIngresos.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(22, 22);
            label1.Name = "label1";
            label1.Size = new Size(162, 15);
            label1.TabIndex = 0;
            label1.Text = "Resumen General del Sistema";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(lblTotalventas);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(lblTiendas);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(lblComercios);
            groupBox1.Controls.Add(label2);
            groupBox1.Location = new Point(22, 59);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(313, 155);
            groupBox1.TabIndex = 1;
            groupBox1.TabStop = false;
            groupBox1.Text = "Totales";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(6, 34);
            label2.Name = "label2";
            label2.Size = new Size(67, 15);
            label2.TabIndex = 2;
            label2.Text = "Comercios:";
            // 
            // lblComercios
            // 
            lblComercios.AutoSize = true;
            lblComercios.Location = new Point(149, 34);
            lblComercios.Name = "lblComercios";
            lblComercios.Size = new Size(13, 15);
            lblComercios.TabIndex = 3;
            lblComercios.Text = "0";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(6, 67);
            label3.Name = "label3";
            label3.Size = new Size(51, 15);
            label3.TabIndex = 4;
            label3.Text = "Tiendas:";
            // 
            // lblTiendas
            // 
            lblTiendas.AutoSize = true;
            lblTiendas.Location = new Point(149, 67);
            lblTiendas.Name = "lblTiendas";
            lblTiendas.Size = new Size(13, 15);
            lblTiendas.TabIndex = 5;
            lblTiendas.Text = "0";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(6, 99);
            label4.Name = "label4";
            label4.Size = new Size(84, 15);
            label4.TabIndex = 6;
            label4.Text = "Ventas Totales:";
            // 
            // lblTotalventas
            // 
            lblTotalventas.AutoSize = true;
            lblTotalventas.Location = new Point(149, 99);
            lblTotalventas.Name = "lblTotalventas";
            lblTotalventas.Size = new Size(13, 15);
            lblTotalventas.TabIndex = 2;
            lblTotalventas.Text = "0";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(lblRechazados);
            groupBox2.Controls.Add(lblPendientes);
            groupBox2.Controls.Add(lblAprobados);
            groupBox2.Controls.Add(label7);
            groupBox2.Controls.Add(label6);
            groupBox2.Controls.Add(label5);
            groupBox2.Location = new Point(22, 245);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(313, 163);
            groupBox2.TabIndex = 2;
            groupBox2.TabStop = false;
            groupBox2.Text = "Estado de Pagos";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(6, 35);
            label5.Name = "label5";
            label5.Size = new Size(68, 15);
            label5.TabIndex = 3;
            label5.Text = "Aprobados:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(6, 71);
            label6.Name = "label6";
            label6.Size = new Size(68, 15);
            label6.TabIndex = 4;
            label6.Text = "Pendientes:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(6, 107);
            label7.Name = "label7";
            label7.Size = new Size(72, 15);
            label7.TabIndex = 4;
            label7.Text = "Rechazados:";
            // 
            // lblAprobados
            // 
            lblAprobados.AutoSize = true;
            lblAprobados.Location = new Point(149, 35);
            lblAprobados.Name = "lblAprobados";
            lblAprobados.Size = new Size(13, 15);
            lblAprobados.TabIndex = 5;
            lblAprobados.Text = "0";
            // 
            // lblPendientes
            // 
            lblPendientes.AutoSize = true;
            lblPendientes.Location = new Point(149, 71);
            lblPendientes.Name = "lblPendientes";
            lblPendientes.Size = new Size(13, 15);
            lblPendientes.TabIndex = 6;
            lblPendientes.Text = "0";
            // 
            // lblRechazados
            // 
            lblRechazados.AutoSize = true;
            lblRechazados.Location = new Point(149, 107);
            lblRechazados.Name = "lblRechazados";
            lblRechazados.Size = new Size(13, 15);
            lblRechazados.TabIndex = 7;
            lblRechazados.Text = "0";
            // 
            // grpIngresos
            // 
            grpIngresos.Controls.Add(lblIngresos);
            grpIngresos.Controls.Add(label8);
            grpIngresos.Location = new Point(28, 432);
            grpIngresos.Name = "grpIngresos";
            grpIngresos.Size = new Size(307, 100);
            grpIngresos.TabIndex = 3;
            grpIngresos.TabStop = false;
            grpIngresos.Text = "Ingresos";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(6, 43);
            label8.Name = "label8";
            label8.Size = new Size(83, 15);
            label8.TabIndex = 4;
            label8.Text = "Total Ingresos:";
            // 
            // lblIngresos
            // 
            lblIngresos.AutoSize = true;
            lblIngresos.Location = new Point(143, 43);
            lblIngresos.Name = "lblIngresos";
            lblIngresos.Size = new Size(19, 15);
            lblIngresos.TabIndex = 5;
            lblIngresos.Text = "0$";
            // 
            // btnActualizar
            // 
            btnActualizar.Location = new Point(260, 556);
            btnActualizar.Name = "btnActualizar";
            btnActualizar.Size = new Size(75, 23);
            btnActualizar.TabIndex = 4;
            btnActualizar.Text = "&Actualizar";
            btnActualizar.UseVisualStyleBackColor = true;
            // 
            // ResumenForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(381, 620);
            Controls.Add(btnActualizar);
            Controls.Add(grpIngresos);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(label1);
            Name = "ResumenForm";
            Text = "ResumenForm";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            grpIngresos.ResumeLayout(false);
            grpIngresos.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private GroupBox groupBox1;
        private Label lblTiendas;
        private Label label3;
        private Label lblComercios;
        private Label label2;
        private Label lblTotalventas;
        private Label label4;
        private GroupBox groupBox2;
        private Label lblRechazados;
        private Label lblPendientes;
        private Label lblAprobados;
        private Label label7;
        private Label label6;
        private Label label5;
        private GroupBox grpIngresos;
        private Label lblIngresos;
        private Label label8;
        private Button btnActualizar;
    }
}