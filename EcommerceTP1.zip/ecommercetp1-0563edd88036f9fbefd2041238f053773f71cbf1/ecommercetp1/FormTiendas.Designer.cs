﻿namespace ecommercetp1
{
    partial class FormTiendas
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            txtIdTienda = new TextBox();
            txtUrl = new TextBox();
            btn_Eliminar = new Button();
            btn_Buscar = new Button();
            dgvTiendas = new DataGridView();
            cmbUsuario = new ComboBox();
            cmbEstado = new ComboBox();
            groupBox1 = new GroupBox();
            button2 = new Button();
            button1 = new Button();
            label6 = new Label();
            textBox1 = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dgvTiendas).BeginInit();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(6, 33);
            label1.Name = "label1";
            label1.Size = new Size(43, 15);
            label1.TabIndex = 0;
            label1.Text = "Tienda";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(6, 91);
            label3.Name = "label3";
            label3.Size = new Size(59, 15);
            label3.TabIndex = 2;
            label3.Text = "Comercio";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(6, 62);
            label4.Name = "label4";
            label4.Size = new Size(28, 15);
            label4.TabIndex = 3;
            label4.Text = "URL";
            label4.Click += label4_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(7, 120);
            label5.Name = "label5";
            label5.Size = new Size(42, 15);
            label5.TabIndex = 4;
            label5.Text = "Estado";
            // 
            // txtIdTienda
            // 
            txtIdTienda.Location = new Point(101, 30);
            txtIdTienda.Name = "txtIdTienda";
            txtIdTienda.Size = new Size(121, 23);
            txtIdTienda.TabIndex = 5;
            // 
            // txtUrl
            // 
            txtUrl.Location = new Point(101, 59);
            txtUrl.Name = "txtUrl";
            txtUrl.Size = new Size(121, 23);
            txtUrl.TabIndex = 8;
            // 
            // btn_Eliminar
            // 
            btn_Eliminar.Location = new Point(442, 116);
            btn_Eliminar.Name = "btn_Eliminar";
            btn_Eliminar.Size = new Size(75, 23);
            btn_Eliminar.TabIndex = 16;
            btn_Eliminar.Text = "&Eliminar";
            btn_Eliminar.UseVisualStyleBackColor = true;
            btn_Eliminar.Click += btn_Eliminar_Click;
            // 
            // btn_Buscar
            // 
            btn_Buscar.Location = new Point(361, 117);
            btn_Buscar.Name = "btn_Buscar";
            btn_Buscar.Size = new Size(75, 23);
            btn_Buscar.TabIndex = 17;
            btn_Buscar.Text = "&Modificar";
            btn_Buscar.UseVisualStyleBackColor = true;
            btn_Buscar.Click += btn_Buscar_Click;
            // 
            // dgvTiendas
            // 
            dgvTiendas.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvTiendas.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvTiendas.Location = new Point(13, 236);
            dgvTiendas.Name = "dgvTiendas";
            dgvTiendas.Size = new Size(625, 150);
            dgvTiendas.TabIndex = 18;
            dgvTiendas.CellClick += dgvTiendas_CellClick;
            // 
            // cmbUsuario
            // 
            cmbUsuario.FormattingEnabled = true;
            cmbUsuario.Location = new Point(101, 88);
            cmbUsuario.Name = "cmbUsuario";
            cmbUsuario.Size = new Size(121, 23);
            cmbUsuario.TabIndex = 19;
            // 
            // cmbEstado
            // 
            cmbEstado.FormattingEnabled = true;
            cmbEstado.Location = new Point(101, 117);
            cmbEstado.Name = "cmbEstado";
            cmbEstado.Size = new Size(121, 23);
            cmbEstado.TabIndex = 20;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(button2);
            groupBox1.Controls.Add(button1);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(btn_Buscar);
            groupBox1.Controls.Add(cmbEstado);
            groupBox1.Controls.Add(txtIdTienda);
            groupBox1.Controls.Add(btn_Eliminar);
            groupBox1.Controls.Add(cmbUsuario);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(txtUrl);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label5);
            groupBox1.Location = new Point(13, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(625, 152);
            groupBox1.TabIndex = 21;
            groupBox1.TabStop = false;
            groupBox1.Text = "Datos de la Tienda";
            // 
            // button2
            // 
            button2.Location = new Point(523, 116);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 22;
            button2.Text = "&Limpiar";
            button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.Location = new Point(280, 117);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 21;
            button1.Text = "&Agregar";
            button1.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(20, 183);
            label6.Name = "label6";
            label6.Size = new Size(48, 15);
            label6.TabIndex = 23;
            label6.Text = "Buscar: ";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(74, 180);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(117, 23);
            textBox1.TabIndex = 24;
            // 
            // FormTiendas
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(695, 437);
            Controls.Add(textBox1);
            Controls.Add(label6);
            Controls.Add(groupBox1);
            Controls.Add(dgvTiendas);
            Name = "FormTiendas";
            Text = "Form1";
            Load += FormTiendas_Load;
            ((System.ComponentModel.ISupportInitialize)dgvTiendas).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label3;
        private Label label4;
        private Label label5;
        private TextBox txtIdTienda;
        private TextBox txtUrl;
        private Button btn_Eliminar;
        private Button btn_Buscar;
        private DataGridView dgvTiendas;
        private ComboBox cmbUsuario;
        private ComboBox cmbEstado;
        private GroupBox groupBox1;
        private Button button2;
        private Button button1;
        private Label label6;
        private TextBox textBox1;
    }
}
