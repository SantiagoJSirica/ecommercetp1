using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ecommercetp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void usuariosMI_Click(object sender, EventArgs e)
        {
            foreach (Form hijo in this.MdiChildren)
            {
                if (hijo is UsuariosForm)
                {
                    hijo.Activate();
                    return;
                }
            }

            UsuariosForm form = new UsuariosForm();
            form.MdiParent = this;
            form.Show();
        }

        private void tiendasMI_Click(object sender, EventArgs e)
        {
            foreach (Form hijo in this.MdiChildren)
            {
                if (hijo is FormTiendas)
                {
                    hijo.Activate();
                    return;
                }
            }

            FormTiendas form = new FormTiendas();
            form.MdiParent = this;
            form.Show();

        }

        private void comercioMI_Click(object sender, EventArgs e)
        {
            foreach (Form f in this.MdiChildren)
            {
                if (f is ComerciosForm)
                {
                    f.Activate();
                    return;
                }
            }

            ComerciosForm frm = new ComerciosForm();
            frm.MdiParent = this;
            frm.Show();
        }

        private void ventasMI_Click(object sender, EventArgs e)
        {
            foreach (Form f in this.MdiChildren)
            {
                if (f is VentasForm)
                {
                    f.Activate();
                    return;
                }
            }

            VentasForm frm = new VentasForm();
            frm.MdiParent = this;
            frm.Show();
        }

        private void logisticaMI_Click(object sender, EventArgs e)
        {
            foreach (Form f in this.MdiChildren)
            {
                if (f is LogisticaForm)
                {
                    f.Activate();
                    return;
                }
            }

            LogisticaForm frm = new LogisticaForm();
            frm.MdiParent = this;
            frm.Show();
        }

        private void resumenMI_Click(object sender, EventArgs e)
        {
            foreach (Form f in this.MdiChildren)
            {
                if (f is ResumenForm)
                {
                    f.Activate();
                    return;
                }
            }

            ResumenForm frm = new ResumenForm();
            frm.MdiParent = this;
            frm.Show();
        }
    }
}